import {applyTheme as _applyTheme} from './theme-Product-Management-2_4_0.generated.js';
export const applyTheme = _applyTheme;
